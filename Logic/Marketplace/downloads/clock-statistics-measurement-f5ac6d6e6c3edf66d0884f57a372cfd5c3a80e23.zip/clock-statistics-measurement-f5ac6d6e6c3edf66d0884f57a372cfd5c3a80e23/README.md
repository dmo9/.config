# Clock Statistics Measurement

Saleae Software Measurement Extension to Calculate Clock Signal Statistics
